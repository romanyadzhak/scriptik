<?php
// Heading
$_['heading_title']    = 'Themes';

// Text
$_['text_success']     = 'Success: You have modified themes!';

// Column
$_['column_name']      = 'Theme Name';
$_['column_status']    = 'Status';
$_['column_action']    = 'Action';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify themes!';
$_['error_extension']  = 'Warning: Extension does not exist!';
