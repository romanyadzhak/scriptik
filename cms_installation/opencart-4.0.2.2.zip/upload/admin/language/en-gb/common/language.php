<?php
$_['error_language'] = 'Warning: Language could not be found!';